import { Component } from '@angular/core';

@Component({
  selector: 'app-producto-lista',
  imports: [],
  templateUrl: './producto-lista.component.html'
})
export class ProductoListaComponent {

}
