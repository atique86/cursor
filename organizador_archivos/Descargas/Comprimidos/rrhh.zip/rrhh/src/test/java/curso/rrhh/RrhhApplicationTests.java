package curso.rrhh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RrhhApplicationTests {

	@Test
	void contextLoads() {
	}

}
